# Vishnu's Bank – Loan Eligibility & Approval System

**Eclipse project name:** `VishnuBankLoanEligibilitySystem`  
**Project title:** Vishnu's Bank – Loan Eligibility & Approval System  
**Language:** Core Java  
**Application type:** Console-based

## Overview
This learning project demonstrates a simple eligibility check for Gold Loan, Home Loan and Personal Loan. It collects customer details, checks sample eligibility conditions, validates the entered Aadhaar/PAN/phone formats, and displays a demo approval/rejection result.

## Project structure
```text
VishnuBankLoanEligibilitySystem/
├── src/
│   └── projects/
│       ├── Loan.java
│       ├── GoldLoan.java
│       ├── HomeLoan.java
│       └── PersonalLoan.java
└── README.md
```

## How to import into Eclipse
1. Extract this ZIP file.
2. Open Eclipse.
3. Choose **File → Import → General → Existing Projects into Workspace** if the project has Eclipse metadata, or create a new Java Project named `VishnuBankLoanEligibilitySystem`.
4. If creating a new project, copy the `src/projects` folder into the new project's `src` folder.
5. Confirm the package is named `projects`.
6. Run `GoldLoan.java`, `HomeLoan.java`, or `PersonalLoan.java` using **Run As → Java Application**.

## Sample input
- CIBIL: `780`
- Annual salary: `1200000`
- Age: `30`
- Aadhaar (dummy format only): `123456789012`
- PAN (dummy format only): `ABCDE1234F`
- Phone (dummy format only): `9876543210`
- Address: `Hyderabad`

## Sample eligibility rules
| Loan type | CIBIL | Annual salary | Age | Demo ROI |
|---|---:|---:|---:|---:|
| Gold Loan | > 650 | Not checked | > 21 | 10.0% |
| Home Loan | > 700 | > ₹300,000 | > 21 | 8.5% |
| Personal Loan | > 760 | > ₹1,000,000 | > 25 | 12.0% |

All loan types also require the entered Aadhaar, PAN and phone values to pass format checks.

## Java concepts demonstrated
- Classes and objects
- Inheritance (`extends Loan`)
- Method overriding (`getROI()`)
- Constructors
- Methods and return values
- Conditional statements and logical AND (`&&`)
- Scanner-based console input
- Strings and regular expressions
- Packages

**Abstraction note:** This version does not use an abstract class or interface. `Loan` is a concrete parent class.  
**Encapsulation note:** The customer fields are `protected`, so encapsulation is partial rather than strict.  
**KYC note:** The regular expressions check format only. They do not verify a real identity or contact number. Use dummy values only; never enter real Aadhaar, PAN or other sensitive details into this practice project.  
**Banking note:** Eligibility thresholds and ROI values are illustrative learning-project values, not actual bank policies or loan offers.
